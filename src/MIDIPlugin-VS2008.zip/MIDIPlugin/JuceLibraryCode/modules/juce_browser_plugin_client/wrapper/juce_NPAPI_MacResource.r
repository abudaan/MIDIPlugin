#include <CoreServices/CoreServices.r>
#include "BrowserPluginCharacteristics.h"

resource 'STR#' (126) { {
    JuceBrowserPlugin_Desc,
    JuceBrowserPlugin_Name
} };

resource 'STR#' (127) { {
    JuceBrowserPlugin_FileSuffix
} };

resource 'STR#' (128) { {
    JuceBrowserPlugin_MimeType,
    JuceBrowserPlugin_FileSuffix
} };
