/*
  ==============================================================================

   This file is part of the JUCE library - "Jules' Utility Class Extensions"
   Copyright 2004-11 by Raw Material Software Ltd.

  ------------------------------------------------------------------------------

   JUCE can be redistributed and/or modified under the terms of the GNU General
   Public License (Version 2), as published by the Free Software Foundation.
   A copy of the license is included in the JUCE distribution, or can be found
   online at www.gnu.org/licenses.

   JUCE is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
   A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

  ------------------------------------------------------------------------------

   To release a closed-source product which uses JUCE, commercial licenses are
   available: visit www.rawmaterialsoftware.com/juce for more information.

  ==============================================================================
 
 http://groups.google.com/group/native-client-discuss/browse_thread/thread/cab63dcd4f734428
 
 */

#include "JuceHeader.h"
#include <sstream>

/*
template <class T>
inline std::string to_string (const T& t)
{
        std::stringstream ss;
        ss << t;
        return ss.str();
}
 */


//==============================================================================

/**
    This is our top-level component for our plugin..
 */


class JuceDemoBrowserPlugin : public BrowserPluginComponent {
    //==============================================================================

    /** This is the javascript object that the browser uses when the webpage accesses
        methods or properties on our plugin object.
     */
    class DemoBrowserObject : public DynamicObject {
    public:

        DemoBrowserObject(JuceDemoBrowserPlugin* owner_)
        : owner(owner_) {
            // Add a couple of methods to our object..
            setMethod("registerCallbackObject", (var::MethodFunction) & DemoBrowserObject::registerCallbackObject);

            setMethod("getMIDIInputs", (var::MethodFunction) & DemoBrowserObject::getMIDIInputs);
            setMethod("getMIDIOutputs", (var::MethodFunction) & DemoBrowserObject::getMIDIOutputs);
            setMethod("addConnection", (var::MethodFunction) & DemoBrowserObject::addConnection);
            setMethod("cleanup", (var::MethodFunction) & DemoBrowserObject::cleanup);


            // Add some value properties that the webpage can access
            setProperty("property1", "testing");
            setProperty("property2", 12345678.0);
        }

        //==============================================================================
        // These methods are called by javascript in the webpage...

        const var registerCallbackObject(const var* params, int numParams) {
            if (numParams > 0) {
                owner->setJavascriptObjectFromBrowser(params[0]);
            }
            return var::null;
        }

        const var getMIDIInputs(const var* params, int numParams) {
            StringArray inputs = MidiInput::getDevices();
            owner->setInputDevices(inputs);
            return inputs.joinIntoString(",");
        }

        const var getMIDIOutputs(const var* params, int numParams) {
            StringArray outputs = MidiOutput::getDevices();
            owner->setOutputDevices(outputs);
            return outputs.joinIntoString(",");
        }

        const var addConnection(const var* params, int numParams) {
            return owner->addConnection(params, numParams);
        }

        const var cleanup(const var* params, int numParams) {
            owner->cleanup();
			return var::null;
        }

        //==============================================================================
        JuceDemoBrowserPlugin* owner;
    };

    class MidiInputListener : public MidiInputCallback {
    public:

        MidiInputListener(JuceDemoBrowserPlugin* owner_) : owner(owner_) {
        }

        void handleIncomingMidiMessage(MidiInput* source, const MidiMessage& message) {
            owner->parseMIDIMessage(source, message);
        }

        JuceDemoBrowserPlugin* owner;
    };


public:

    JuceDemoBrowserPlugin() {
        ourJavascriptObject = new DemoBrowserObject(this);
        inputListener = new MidiInputListener(this);
        noDevice = -1;
        midiInputId = noDevice;
        midiOutputId = noDevice;
        hasMidiInput = false;
        hasMidiOutput = false;
        buffer = "";
    }

    var getJavascriptObject() {
        // The browser calls this to get the javascript object that represents our plugin..
        return ourJavascriptObject;
    }

    void paint(Graphics& g) {
        g.fillAll(Colours::white);
    }

    void setJavascriptObjectFromBrowser(var callbackObject) {
        javascriptObjectFromBrowser = callbackObject;
    }

    void setInputDevices(StringArray inputs) {
        for (int i = 0; i < inputs.size(); i++) {
            midiInputs[i] = inputs[i];
        }
    }

    void setOutputDevices(StringArray outputs) {
        for (int i = 0; i < outputs.size(); i++) {
            midiOutputs[i] = outputs[i];
        }
    }

    void printMessage(String message) {
        javascriptObjectFromBrowser.call("printmessage", message);
    }

    void parseMIDIMessage(MidiInput* source, const MidiMessage& message) {

        //TODO: determine which messages should go to which outputs!
        if (hasMidiOutput) {
            midiOutput->sendMessageNow(message);
        }

        String note = String(message.getNoteNumber());
        String velocity = String(message.getVelocity());
        String channel = String(message.getChannel());
        //String command = message.isNoteOn() ? "140" : "";
        String midiMessage = "";
        midiMessage.append(note, sizeof (note));
        midiMessage.append(",", 1);
        midiMessage.append(velocity, sizeof (velocity));
        //midiMessage.append(",",1);
        //midiMessage.append(command,sizeof(command));
        printMessage(midiMessage);
    }

    var addConnection(const var* params, int numParams) {

        cleanup();

        if (numParams >= 1) {

            buffer = "";

            try {
                midiInput = MidiInput::openDevice(params[0], inputListener);
                hasMidiInput = true;

                String inputName = midiInputs[params[0]];
                buffer.append(inputName, inputName.length());


                if (numParams >= 2) {
                    midiOutput = MidiOutput::openDevice(params[1]);
                    hasMidiOutput = true;

                    buffer.append(" connected to ", 14);
                    String outputName = midiOutputs[params[1]];
                    buffer.append(outputName, outputName.length());

                } else {
                    hasMidiOutput = false;
                    buffer.append(" connected", 10);
                }

                if (&midiInput != 0) {
                    midiInput->start();
                } else {
                }

            } catch (int e) {
                return String(e);
            }
            return buffer;
        } else {
            return "Please choose at least a MIDI input";
        }
    }

    void cleanup() {
        if (hasMidiInput) {
            midiInput->stop();
            midiInput->~MidiInput();
            //return "input exists";
        }

        if (hasMidiOutput) {
            midiOutput->stopBackgroundThread();
            midiOutput->~MidiOutput();
            //return "output exists";
        }
    }

    var ourJavascriptObject;
    var javascriptObjectFromBrowser;
    String buffer;
    MidiInput* midiInput;
    MidiOutput* midiOutput;
    MidiInputListener* inputListener;
    var noDevice;
    int midiInputId;
    int midiOutputId;
    bool hasMidiInput;
    bool hasMidiOutput;
    String midiInputs[50];
    String midiOutputs[50];

};

BrowserPluginComponent* JUCE_CALLTYPE createBrowserPlugin() {
    return new JuceDemoBrowserPlugin();
}
