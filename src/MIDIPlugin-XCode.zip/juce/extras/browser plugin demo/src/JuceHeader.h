/*
  ==============================================================================

  This file contains values that describe your plugin's behaviour.

  ==============================================================================
*/


#include "AppConfig.h"
#include "../../../modules/juce_browser_plugin/juce_browser_plugin.h"
#include "../../../modules/juce_audio_basics/juce_audio_basics.h"
#include "../../../modules/juce_audio_formats/juce_audio_formats.h"
#include "../../../modules/juce_audio_devices/juce_audio_devices.h"
#include "../../../modules/juce_audio_processors/juce_audio_processors.h"

#if ! DONT_SET_USING_JUCE_NAMESPACE
 /* If you're not mixing JUCE with other libraries, then this will obviously save
    a lot of typing, but can be disabled by setting DONT_SET_USING_JUCE_NAMESPACE.
 */
 using namespace juce;
#endif
