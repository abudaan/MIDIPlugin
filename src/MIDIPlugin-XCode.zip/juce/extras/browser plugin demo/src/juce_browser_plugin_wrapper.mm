
#include "AppConfig.h"
#include "../../../modules/juce_browser_plugin/juce_browser_plugin.cpp"
#include "../../../modules/juce_audio_basics/juce_audio_basics.cpp"
#include "../../../modules/juce_audio_formats/juce_audio_formats.cpp"
#include "../../../modules/juce_audio_devices/juce_audio_devices.cpp"
#include "../../../modules/juce_audio_processors/juce_audio_processors.cpp"
