
#include "amalgamation/juce_amalgamated_template.cpp"
